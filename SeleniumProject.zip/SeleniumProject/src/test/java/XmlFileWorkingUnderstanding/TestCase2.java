package XmlFileWorkingUnderstanding;

import org.testng.annotations.Test;

public class TestCase2 {
    @Test
	public void test3() {
		System.out.println("Test3");
	}
		@Test
	public void test4() {
		System.out.println("Test4");
	}

}
