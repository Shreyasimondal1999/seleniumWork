package XmlFileWorkingUnderstanding;

import org.testng.annotations.Test;

public class Testcase4 {
    @Test
	public void test7() {
		System.out.println("Test7");
	}
		@Test
	public void test8() {
		System.out.println("Test8");
	}
}
