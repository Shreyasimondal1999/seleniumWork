package XmlFileWorkingUnderstanding;
import org.testng.annotations.*;
public class TestCase5 {
	@Test
public void test9() {
	System.out.println("Test9");
}
	@Test
public void test10() {
	System.out.println("Test10");
}

}
