package XmlFileWorkingUnderstanding;

import org.testng.annotations.Test;

public class Testcase3 {
    @Test
	public void test5() {
		System.out.println("Test5");
	}
		@Test
	public void test6() {
		System.out.println("Test6");
	}
}
