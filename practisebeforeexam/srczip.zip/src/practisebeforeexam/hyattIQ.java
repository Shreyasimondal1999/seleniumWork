package practisebeforeexam;

public class hyattIQ {

}
